from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin

app = Flask(__name__)

todos = [
    {
        "tarea": "Operacion manual",
        "completado": False
    },
    {
        "tarea": "Autoapply en CMS Strapi",
        "completado": False
    },
    {
        "tarea": "Dashboard de aplicaciones",
        "completado": False
    }
]


@app.route('/api/todos', methods=['GET'])
@cross_origin(supports_credentials=True)
def get_all_todos():
    return jsonify({
        'todos': todos,
        'status': 'success'
    })


@app.route('/api/todos', methods=['POST'])
@cross_origin(supports_credentials=True)
def add_todo():
    todo = request.json
    todos.append({
        'tarea': todo['tarea'],
        'completado': todo['completado']
    })
    return jsonify(todos)


@app.route('/api/todos/<int:todo_index>', methods=['PUT'])
@cross_origin(supports_credentials=True)
def update_todo(todo_index):
    global todos
    todo = request.json
    completado = todo["completado"]
    if 0 <= todo_index < len(todos):
        todos[todo_index]['completado'] = completado
        return jsonify(completado)
    return jsonify({'error': 'Not found'}), 404


@app.route('/api/todos/<int:todo_index>', methods=['DELETE'])
@cross_origin(supports_credentials=True)
def delete_todo(todo_index):
    global todos
    if 0 <= todo_index < len(todos):
        todos.pop(todo_index)
        return jsonify(todos)
    return jsonify({'error': 'Not Found'}), 404


if __name__ == '__main__':
    app.run(debug=True)

CORS(app, support_credentials=True)
